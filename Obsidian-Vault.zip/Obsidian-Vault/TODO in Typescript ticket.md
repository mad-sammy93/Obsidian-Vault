- [ ] Move icon types to iconTypes file
      - name them IconSize and IconTheme 
- [ ] Add types in common file
- [ ] Test The changes
- [ ] Double check
- [ ] test
 