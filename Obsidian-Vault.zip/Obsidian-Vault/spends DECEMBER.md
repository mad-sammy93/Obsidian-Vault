hun 2000
Henry Gift 1000
Alisther gift 3500
sebiola 1000 for home stuff
redbus 1365

- 
fuel
- 680
food+cigs+
- 180
- 240
-

- 100
- 328 Royal foods
- 340
- 442
- 479 swiggy


