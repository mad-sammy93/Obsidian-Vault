2 beef cutlet
2 shwarma
1 vada pao


3 resois(shubman amd me)


