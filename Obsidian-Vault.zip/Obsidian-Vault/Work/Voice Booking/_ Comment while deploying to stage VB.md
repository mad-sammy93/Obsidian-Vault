
/Ansible/group_vars/all/vars


comment the following
- "ACCESS_KEY='{{vault_s3_db_backup_access_key}}'"
- "SECRET_KEY='{{vault_s3_db_backup_secret_key}}'"
- "PASSWORD='{{vault_s3_db_backup_encryption_key}}'"
- "WEBHOOK_URL='{{vault_s3_db_backup_slack_hook}}'"
- "BUCKET='{{bucket_name}}'"
- "MYSQL_PORT='{{mysql_port}}"

