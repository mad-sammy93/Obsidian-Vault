usp card and usp diagonal card

not able to add segmant on dutch
Yellow segment with logos

Welcome at -> to Voicebooking

