on logout of vb site 
send a logout api request and the get the response
based on the logout response delete the pp token