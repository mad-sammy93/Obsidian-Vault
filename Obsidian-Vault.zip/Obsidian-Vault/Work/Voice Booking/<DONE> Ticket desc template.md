**Expected behavior**

I expect the sections ...

**Actual behavior**

The sections (USP Card Block and USP Diagonal Block) keep on changing:

- Pictures switching
    
- Titles switching
    

**Steps to reproduce**

We fixed it Tuesday morning Aug 15th, but might break soon. As last time we fixed it on Thursday and Friday it was broken again.

Check on the homepage for all 4 languages:

- [https://www.voicebooking.com/de](https://www.voicebooking.com/de)
    
- [https://www.voicebooking.com/en](https://www.voicebooking.com/en)
    
- [https://www.voicebooking.com/nl](https://www.voicebooking.com/nl)
    
- [https://www.voicebooking.com/fr](https://www.voicebooking.com/fr)