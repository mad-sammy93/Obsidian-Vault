
## VB-370

- code in functions.php
- update fonts and fields
 
## VB-369
### order of showing 

- Cookie > lang redirect > lang rec >  t > chat bot

We use cookies to make your experience better. To comply with the new e-Privacy directive, we need to ask for your consent to set the cookies. [cookies_policy_link]

## VB-368


- On logout of Project pages/ voice booking

- send logiut api request 

- send pp token as bearer
- [[T25 13th Oct 2023]]
