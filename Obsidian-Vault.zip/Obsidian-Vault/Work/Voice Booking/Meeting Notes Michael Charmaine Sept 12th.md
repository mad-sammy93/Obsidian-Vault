# meeting notes

## cutomer never has dorect contact with customer before booking is final

When th ebookingis final the cha

Request fee should be  start briefing
-> can create a project-> has to be accepted
->form comes in mail

------------


if we start a breifing it should be a briedinfg

if they use taht url the backend will handle the rest

only voiceover taht are set to be contacted by agents

reset will remain the same

if its set to agent the they are not allowed to see the form





