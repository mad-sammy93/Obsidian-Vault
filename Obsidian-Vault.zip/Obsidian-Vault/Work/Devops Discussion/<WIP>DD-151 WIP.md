- [x] Table topbar z-index style issues
- [x] fixed dropdown issue 
- [x] custom pagination issues
- [x] remove placehomlder text(*change status*)
- [x] change behaviour of of confirm popup if active option is selected. 


fixed dropdown


>[!Meeting notes]
>
> - [ x ] test
> - worth haveing the not verified status to be changed by admin
> - warning for admin while changing the status by the admin
> - 



##### DD backend information

- [ ] Backlog of code  
      waiting for auth module to be done
      
