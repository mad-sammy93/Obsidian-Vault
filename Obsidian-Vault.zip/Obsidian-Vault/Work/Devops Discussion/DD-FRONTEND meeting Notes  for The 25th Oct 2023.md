### Notes DD-FRONTEND meeting



- Change ZIPCODE -> Zipcode
	-  keep a  generic regex format for zipcode








