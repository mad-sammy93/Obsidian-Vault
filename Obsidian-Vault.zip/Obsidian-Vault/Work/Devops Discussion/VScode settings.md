## Formatting
semicolon
space
inverted comas









```
{

"yaml.schemas": {

"file:///home/sambert/.vscode/extensions/atlassian.atlascode-3.0.7/resources/schemas/pipelines-schema.json": "bitbucket-pipelines.yml"

},

"redhat.telemetry.enabled": true,

"editor.guides.bracketPairs": true,

"editor.defaultFormatter": "esbenp.prettier-vscode",

"editor.linkedEditing": true,

"workbench.colorTheme": "Dracula",

"editor.renderWhitespace": "none",

"workbench.iconTheme": "material-icon-theme",

"chatgpt.chromiumPath": "/opt/google/chrome/google-chrome",

"microsoftteams.teamswebhook": "",

"chatgpt.gpt3.apiKey": "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",

"php.validate.executablePath": "",

"[vue]": {

"editor.defaultFormatter": "Vue.volar"

},

"[php]": {

"editor.defaultFormatter": "apility.beautify-blade"

},

"todo-tree.general.tags": [

"BUG",

"HACK",

"FIXME",

"TODO",

"XXX",

"[ ]",

"[x]",

"CLEAN",

"FUTURE"

],

"todo-tree.general.tagGroups": {},

"errorLens.lintFilePaths": {

"eslint": ["**/*.eslintrc.{js,cjs,yaml,yml,json}", "**/*package.json"],

"Stylelint": [

"**/*.stylelintrc",

"**/*.stylelintrc.{cjs,js,json,yaml,yml}",

"**/*stylelint.config.{cjs,js}",

"**/*package.json"

]

},

"[typescript]": {

"editor.defaultFormatter": "vscode.typescript-language-features"

},

"[scss]": {

"editor.defaultFormatter": "apility.beautify-blade"

},

"editor.formatOnSaveMode": "modifications",

"files.associations": {

"*.sass": "sass"

},

"[sass]": {

"editor.defaultFormatter": "sasa.vscode-sass-format"

},

"window.zoomLevel": 1,

"terminal.integrated.env.linux": {},

"editor.tabSize": 2,

"editor.indentSize": "tabSize"

}
```

