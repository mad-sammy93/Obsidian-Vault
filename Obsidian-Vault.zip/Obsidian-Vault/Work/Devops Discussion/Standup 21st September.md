# Lisitng company
Managing data in datatables 
added funcitonality for searhc sorting 
- setup of pinia Smartshore

DD frontend is deployed on staging


# Company update on 3rd october

-- Backed login swagger
-- db design , nitpicking 

## Presentation content
FE
``` how we got to the design done ```
``` how that works wth component based design ```
``` how it works with billing```

## changes to do 
responsive on auth screens
OTP grey out submit on timer up
change pincode to zipcode

I would like to present Frontend for the upcomming Company Update, I have discussed the same with Ruchira.
Wanted to know what we can include in the presentation.
Also, I would like to get a few pointer on how we can have a good presentaion.
