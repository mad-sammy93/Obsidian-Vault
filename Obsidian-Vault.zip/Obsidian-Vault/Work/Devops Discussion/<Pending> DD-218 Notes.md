## Changes

- [ ] replace color names used with ther names
- [ ] fix icons in dashbar
- [ ] check routes