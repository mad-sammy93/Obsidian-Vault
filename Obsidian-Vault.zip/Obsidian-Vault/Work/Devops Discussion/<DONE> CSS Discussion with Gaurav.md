td.shadow.direction-left {

1. [ ]  position: static !important;

}
td.shadow.direction-left {

1. [ ]  z-index: inherit !important;
2. [ ]  overflow: unset;
3.  position: static !important;

}
.listing-table__body-row {

1. [ ]  /* z-index: 0 !important; */
2. [ ]  position: relative !important;

}
