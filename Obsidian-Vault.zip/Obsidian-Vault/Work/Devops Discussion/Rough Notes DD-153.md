
```
<!-- <input v-model="currentTag" @input="onInputChange" @keydown.enter.prevent="addTag" placeholder="Add tags..." /> -->

<!-- <InputTextControl id="tagsInput" :placeholder="placeholder" v-model="currentTag" @input="onInputChange" @keydown.space.prevent="addTag" @keydown.enter.prevent="addTag" size="small" /> -->

```




### List of monitors(Dummy Data)
- Synthic 
- ping
- Scripted browser
- SSL Check


### Pending


SOlving PR
82868C


