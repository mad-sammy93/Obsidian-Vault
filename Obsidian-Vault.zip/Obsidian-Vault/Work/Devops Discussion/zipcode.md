zipcode  for other countries
califormina london
## find a common mechanism 


TODO

for otp validarion difit full put in commone functions


