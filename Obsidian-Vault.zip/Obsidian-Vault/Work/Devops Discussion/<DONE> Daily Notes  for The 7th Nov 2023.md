WOrking for today 
	Project Listing
	Added multiple new templates as per the additional new headers

TODO:
	Styling for tooltip
	styling project




 