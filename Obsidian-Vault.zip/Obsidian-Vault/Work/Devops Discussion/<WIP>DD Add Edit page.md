```
Router/projects
http://localhost:5002/project/23/edit


{

path: ':id/edit',

name: 'editProject',

component: () => import('@/pages/project/AddProject.vue')

},
```

