		-[ ] Working on button consistency ticket DD-223
    - updated all buttons spacing and consistency
    - fixing sidebar icons
      
- [ ] Still pending Project listing
- [ ] 

  