# Project and roles


### Projects
- Info that we need
- need to be able to create new project

#### Info to add to the project
-- name
-- Project manager
-- People worked on project
-- role of above person (designation)(contributors)
-- previous contributors
-- monitors belonging to project (multiple)
-- hosting
-- awe inspired monitor

-- adding monitor to project to be shown only for admin and not for client.

# Future requiremtns

### adding funcitonality to add support ticket

Digital ocean monitoring
Jira integration(RD) link to jira project
Billing
Info about deployments(who did it , when , build no, etc)

## Roles

same options as projects

Roles have names
access or access without billing
checkmark if it is in roll or not
Descripton of role on mouse over

Project -> assign user -> asign role

Add role 
overview

Role list 
