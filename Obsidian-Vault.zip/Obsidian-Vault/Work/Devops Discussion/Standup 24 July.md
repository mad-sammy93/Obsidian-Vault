## questions to ask Thomas

- Can we go ahead and add more tickets to this sprint or start new sprint
- Working on Pinia , auth , added a the 



### Frontend 
- worksflow how to show newrelic on the frontend

New relic workflow design 

Backup scenarios 
screens and ideas on how to create projects and roles
Multilingual

need another epic to plan our tasks for the next 5 weeks

Tuesday New Relic discussion
Thursday discuss project s and roles

