[[DD-157]]
mrged 
DD-223 with DD-161



add all filter to status drpordown

Take up  roles listing
give estimate

Ruchiras PR
3.5 files per hour



### CREATE TICKET to discuss with back-end
- Discuss colour projects 
- Discuss user deleting process



### Work  7 HOURS  OF WORK

- Project listing dd-161 **1hr**
- Add for All status to Project and Company  **30m**
- DD-128 Slider **2hr**
- Roles Listing  **4hr**

- Message in DEVOPS group once I start working on PR feedback



check company card if used
DD-161 change filter status selected ccolot to blue




