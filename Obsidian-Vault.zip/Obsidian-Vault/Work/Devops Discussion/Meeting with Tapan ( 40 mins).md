- discussion about the dropdown styles
- issues about the tr row getting overflow
- 


