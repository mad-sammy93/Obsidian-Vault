	[[Meeting with Tapan ( 40 mins)]]
	[[Notes for New relic workgflow]]
	[[Project and roles discussion]]
	[[Standup 24 July]]
	[[Standup 21st September]]
	