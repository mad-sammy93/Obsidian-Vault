Discuss with Tapan and Bart about hwo to go about sanitizing the text 
