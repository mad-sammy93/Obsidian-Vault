- [x] change country and state dropdown placehoder to Select
- [x] change title Compoany info -> information
- [x] ZIP Code

