DEVELOPMENT BRANCH

- [x] DD-223 Button Consistency
- [x] DD-153 Add Project
- [x] DD-161 List Project
- [x] Master Add Company 
- [x] DD-163 List Company
- [x] DD-167 Role Listing
- [ ] DD-155 Add Role
- [ ] DD-188 Contributor Listing **(issues with buttons)**
- [ ] Master Add User 
- [ ] DD-157 User Listing

