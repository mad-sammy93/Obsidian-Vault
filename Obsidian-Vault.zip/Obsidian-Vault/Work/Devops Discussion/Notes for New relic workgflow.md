# Notes for New relic workflow

## RD
### features
### Ping
- Duration
- Uptime
- Failures

###  Simple Browser
- whethere to get this directly from api or with some calculations

### Synthetic Login
Website login


### for customnet

?? Report average time - to be calcluated in backend

### What to show 
As Admin - add info to failure from app
Is there an issue
uptime percentages
How much time will it take

just the basic info for both customer and superadmin

User managment 
add project company users

?? Being able to see what customer is seeing


### Support Tickets
As Admin - add info to failure from app
give explainiation to what happen and how to solve it

frontedn

when to create project 
what roles
what monitiores  belong to what project