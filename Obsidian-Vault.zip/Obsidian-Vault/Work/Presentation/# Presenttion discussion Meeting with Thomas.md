# Meeting with Thomas 

- Company Update 45 mins

## general idea 15 mins
- Introduce project 
- Goals
- no deadlines 
- fixed budget

# My part 5 mins

## content

#### Value of Dashboard:
What kind of avalue is DD adding to the 
 - Devops Team
 - Client
 - Smartshore as an organisation

Striving to build a perfect app
Since we do not have a time limit

we can stretch our reseouce to reach close to our goal 
and also encounter solution for many different problem which we may use in other projects as well
#### our flow

- Component based design in figma
    on click in cdesign can change components
    also same in application 
    mention design is done in house

- Crossover between designing and frontend

- Screenshots

- Building those components


















## presentation style 

1- 1.5 mins for a slide

############################################################################################################################

# Points For frontend


Thank you Thomas let me share my screen
#Introduction
Hi guys, Hope  everyone is haveing a good day.

I will be presenting about the Dev Dashboard on behalf of the Frontend team.


# Team Members
Our frontednd teams is made up 2 memebers Ruchira and I.




# Project Stack
The frontend part of teh stack uses:
-  Vue 3 with Vite,
along with Pinia and Docker



# Process of Creating the Designs
## Discussion about requirements/ expectations with the “Client” - Thomas.
- It all kicked off with a discussion with Thomas who is our Project Manager/Client about 
what was required and what are the necessary things we need to show in our app.
Based on The client requirement:




## Multiple brainstorming sessions 
- We had to come up with ideas on what features we fit teh website.
- We had multiple brainstorming sessions and back and forth with Thomas, Bart and Tapan


Once we got the approval we had to Come up with the designs and what we feel the website should looks like.

# How we created the design

- We were separated into 2 teams each comprising of the frontend and backend, putting together ideas.

- we had Multiple brainstorming sessions and exchanging ideas on the look and feel of the website.
- We then picked out the best features of both the designs from both the teams and finalized the screens

- This selection process ensured that we integrated the finest aspects of our collective creativity into the final design.





For the Design:
- Sven gave us a breif tutorial how to use Figma efficeiently and how to use components in figma.




## Developing the Dashboard
We started developing the application Keeping component-based design in priority
- This approach involves breaking down the user interface into reusable components
- This methodology allowsus to maintain visual and functional consistency
- This will not only save development time but also ensure a consistent user experience throughout the dashboard.




## The Power of Component-Based Development

- Faster Development
Component-based methodologies can help teams develop high-quality software up to 60% faster.

- By breaking down our designs into reusable components, we ensured consistency

- By reusing component, teams do not need to start from scratch with their software.
They can directly select from this library without worrying about non-functional requirements 
such as security, usability, or performance.
A component-based architecture extends the modular benefits of a web application to the front end of your project.

- Easier Maintenance
each component is independent and reusable
making any upgrade or modification a breeze.
Rather than modifying the code each time, you need to update the relevant components once

- Improved Scalability
Component-based development allows purpose-built elements to work together like puzzle pieces.

- This allows you and your team to stay up with demand while retaining an easy-to-read and maintainable piece of code at a larger production level.

- As well as maintain quality, by Setting proper code validations and security measure and folowing coding standards.




## Continuous Adaptation
- As development progresses, and having Continuous dialogue with the client and our internal team. 

- This open and transparent communication facilitates quick decision-making and keeping alignment of expectations.
- We will gain further insights into the project's intricacies. 

- As Additional requirements emerge, it facilitates ongoing adjustments and enhancements. 

- Having components gives us the flexibility which allows us to remain aligned with the evolving needs of the project.




##  2 Image slides

These are a few images on how the website is going ot look like






## Future
Our future expectations for the project :

1. Adding new relic api functionality to the Dashboard.
2. Integrating Digital Ocean APIs
3. JIRA Integration 
4. Displaying billing information
This integration aligns with our commitment to staying at the forefront of technological advancements.

It empowers us to adopt a proactive approach to performance management, ensuring that our application
 remains competitive and future-ready




