`#13 17.93 src/components/molecules/form/buttons/CoreButton.vue(80,6): error TS2345: Argument of type '{ size: string; iconFill: boolean; theme: string; }' is not assignable to parameter of type 'never'.`

150

`#13 17.94 src/components/molecules/form/buttons/CoreButton.vue(97,6): error TS2345: Argument of type '{ style: string; size: string; iconFill: boolean; theme: string; }' is not assignable to parameter of type 'never'.`

151

`#13 17.94 src/components/molecules/form/filter/FilterControl.vue(76,18): error TS2322: Type 'DefineComponent<{ theme: { type: PropType<"light" | "dark" | "espresso">; default: string; }; }, {}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, ... 5 more ..., {}>' is not assignable to type 'IconObject | undefined'.`

152

`#13 17.94 Type 'DefineComponent<{ theme: { type: PropType<"light" | "dark" | "espresso">; default: string; }; }, {}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, ... 5 more ..., {}>' is not assignable to type 'IconObject'.`

153

`#13 17.94 src/components/molecules/list/ConfirmModal.vue(4,10): error TS2440: Import declaration conflicts with local declaration of 'defineProps'.`

154

`#13 17.94 src/components/molecules/list/ConfirmModal.vue(4,23): error TS2440: Import declaration conflicts with local declaration of 'defineEmits'.`

155

`#13 17.94 src/pages/company/ListCompany.vue(3,48): error TS2307: Cannot find module 'vue3-easy-data-table' or its corresponding type declarations.`

156

`#13 17.94 src/pages/company/ListCompany.vue(4,30): error TS2307: Cannot find module '@/stores/dataTables' or its corresponding type declarations.`

157

`#13 17.94 src/pages/company/ListCompany.vue(9,26): error TS2307: Cannot find module '@/components/molecules/list/ListingTable.vue' or its corresponding type declarations.`

158

`#13 17.94 src/pages/company/ListCompany.vue(24,31): error TS2339: Property 'getCompanyListing' does not exist on type 'Store<"companies", _UnwrapAll<Pick<{ getStateOptions: () => ({ id: number; value: string; label: string; disabled: boolean; selected: boolean; } | { id: number; value: string; label: string; disabled?: undefined; selected?: undefined; })[]; getCountryOptions: () => ({ ...; } | { ...; })[]; }, never>>, Pick<...>, Pic...'.`

159

`#13 17.94 src/pages/company/ListCompany.vue(39,11): error TS2339: Property 'updateItem' does not exist on type 'Store<"companies", _UnwrapAll<Pick<{ getStateOptions: () => ({ id: number; value: string; label: string; disabled: boolean; selected: boolean; } | { id: number; value: string; label: string; disabled?: undefined; selected?: undefined; })[]; getCountryOptions: () => ({ ...; } | { ...; })[]; }, never>>, Pick<...>, Pic...'.`

160

`#13 17.94 src/pages/company/ListCompany.vue(53,13): error TS2322: Type 'DefineComponent<{ size: { type: PropType<Size>; required: true; }; iconStyle: { type: PropType<Style>; }; }, {}, unknown, {}, {}, ComponentOptionsMixin, ... 6 more ..., {}>' is not assignable to type 'IconObject | undefined'.`

161

`#13 17.94 Type 'DefineComponent<{ size: { type: PropType<Size>; required: true; }; iconStyle: { type: PropType<Style>; }; }, {}, unknown, {}, {}, ComponentOptionsMixin, ... 6 more ..., {}>' is not assignable to type 'IconObject'.`

162

`#13 18.09 error Command failed with exit code 2.`

163

`#13 18.09 info Visit [https://yarnpkg.com/en/docs/cli/run](https://yarnpkg.com/en/docs/cli/run) for documentation about this command.`

164

`#13 18.13 ERROR: "type-check" exited with 2.`

165

`#13 18.18 error Command failed with exit code 1.`

166

`#13 18.18 info Visit [https://yarnpkg.com/en/docs/cli/run](https://yarnpkg.com/en/docs/cli/run) for documentation about this command.`

167

`#13 ERROR: executor failed running [/bin/sh -c yarn build]: exit code: 1`

168

`------`

169

`> [8/8] RUN yarn build:`

170

`------`

171

`executor failed running [/bin/sh -c yarn build]: exit code: 1`